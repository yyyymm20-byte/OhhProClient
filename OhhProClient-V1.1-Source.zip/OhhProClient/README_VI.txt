OHH PRO CLIENT V1.1 — SOURCE PROJECT
Minecraft Java 1.21.11 | Fabric | Java 21 | Zalith Launcher 2

TÍNH NĂNG ĐÃ CÓ
- Click GUI phong cách tím đen, mở bằng RIGHT SHIFT.
- HUD FPS.
- Entity Radar: danh sách tối đa 5 thực thể sống gần nhất trong phạm vi 32 block, kèm khoảng cách.
- Lưu một waypoint tại vị trí hiện tại bằng phím P; waypoint được lưu trong config và tồn tại sau khi thoát game.
- Hiển thị tọa độ và khoảng cách tới waypoint.
- Phím O bật/tắt Entity Radar.

LƯU Ý VỀ TÊN TÍNH NĂNG
Bản này triển khai radar dạng HUD. Chưa có ESP khung viền 3D hoặc đường Tracers 3D trong thế giới; các phần đó cần triển khai riêng bằng pipeline render mới của Minecraft 1.21.11.

BIÊN DỊCH
- Dùng JDK 21 và Gradle.
- Mở project trong IntelliJ IDEA hoặc Android Studio có hỗ trợ Gradle.
- Chạy tác vụ Gradle: build
- JAR đầu ra: build/libs/OhhProClient-1.0.0.jar

CÀI ĐẶT
Chép JAR đầu ra vào thư mục mods của profile Fabric 1.21.11 trong Zalith Launcher 2.
Giữ Fabric API phù hợp với profile.
