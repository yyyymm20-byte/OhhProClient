package com.ohhpro.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class OhhProScreen extends Screen {
    public OhhProScreen() {
        super(Component.literal("OHH PRO CLIENT"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderTransparentBackground(graphics);

        int panelWidth = 286;
        int panelHeight = 196;
        int left = (this.width - panelWidth) / 2;
        int top = (this.height - panelHeight) / 2;

        graphics.fill(left, top, left + panelWidth, top + panelHeight, 0xEE17131F);
        graphics.fill(left, top, left + panelWidth, top + 3, 0xFFB56CFF);

        graphics.drawString(this.font, "OHH PRO CLIENT  V1.1", left + 16, top + 15, 0xFFE4C7FF, false);
        graphics.drawString(this.font, "CLIENT-SIDE UTILITIES", left + 16, top + 39, 0xFFFFFFFF, false);

        graphics.drawString(this.font, "RIGHT SHIFT  -  Open / close menu", left + 16, top + 65, 0xFFCECECE, false);
        graphics.drawString(this.font, "O             -  Entity Radar ON / OFF", left + 16, top + 83, 0xFFCECECE, false);
        graphics.drawString(this.font, "P             -  Save current waypoint", left + 16, top + 101, 0xFFCECECE, false);

        graphics.drawString(this.font, "HUD: FPS + nearby entity radar + waypoint distance",
                left + 16, top + 132, 0xFFBFA7D8, false);
        graphics.drawString(this.font, "Press ESC to close", left + 16, top + 166, 0xFFE4C7FF, false);

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
