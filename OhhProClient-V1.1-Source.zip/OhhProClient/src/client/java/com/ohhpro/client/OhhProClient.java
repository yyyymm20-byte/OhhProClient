package com.ohhpro.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.Properties;

public final class OhhProClient implements ClientModInitializer {
    public static final String MOD_ID = "ohhpro";

    private static KeyMapping openMenuKey;
    private static KeyMapping toggleRadarKey;
    private static KeyMapping saveWaypointKey;

    private static boolean radarEnabled = true;
    private static String waypointLabel = "Chua dat";
    private static double waypointX;
    private static double waypointY;
    private static double waypointZ;
    private static boolean waypointSet;

    private static final Path WAYPOINT_FILE =
            FabricLoader.getInstance().getConfigDir().resolve("ohhpro-waypoint.properties");

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "main")
        );

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.ohhpro.open_menu",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_RIGHT_SHIFT,
                category
        ));

        toggleRadarKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.ohhpro.toggle_radar",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_O,
                category
        ));

        saveWaypointKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.ohhpro.save_waypoint",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_P,
                category
        ));

        loadWaypoint();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new OhhProScreen());
                } else if (client.screen instanceof OhhProScreen) {
                    client.setScreen(null);
                }
            }

            while (toggleRadarKey.consumeClick()) {
                radarEnabled = !radarEnabled;
                if (client.player != null) {
                    client.player.displayClientMessage(
                            Component.literal("OHH PRO Radar: " + (radarEnabled ? "ON" : "OFF")),
                            true
                    );
                }
            }

            while (saveWaypointKey.consumeClick()) {
                if (client.player != null) {
                    waypointX = client.player.getX();
                    waypointY = client.player.getY();
                    waypointZ = client.player.getZ();
                    waypointLabel = "Waypoint";
                    waypointSet = true;
                    saveWaypoint();
                    client.player.displayClientMessage(
                            Component.literal("OHH PRO: Da luu waypoint tai "
                                    + (int) waypointX + ", " + (int) waypointY + ", " + (int) waypointZ),
                            false
                    );
                }
            }
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "client_hud"),
                (graphics, tickCounter) -> {
                    Minecraft client = Minecraft.getInstance();
                    if (client.player == null || client.level == null || client.options.hideGui) {
                        return;
                    }

                    int y = 8;
                    graphics.drawString(client.font,
                            "OHH PRO  |  FPS: " + client.getFps(),
                            8, y, 0xFFCE9BFF, true);
                    y += 12;

                    if (waypointSet) {
                        double dx = waypointX - client.player.getX();
                        double dy = waypointY - client.player.getY();
                        double dz = waypointZ - client.player.getZ();
                        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
                        graphics.drawString(client.font,
                                "WP: " + (int) waypointX + " " + (int) waypointY + " " + (int) waypointZ
                                        + "  [" + (int) distance + "m]",
                                8, y, 0xFFFFD479, true);
                        y += 12;
                    } else {
                        graphics.drawString(client.font, "WP: chua dat (P de luu)", 8, y, 0xFFFFD479, true);
                        y += 12;
                    }

                    if (radarEnabled) {
                        final int maxEntries = 5;
                        java.util.List<Entity> nearby = new java.util.ArrayList<>();
                        for (Entity entity : client.level.entitiesForRendering()) {
                            if (entity == client.player || !entity.isAlive()) continue;
                            if (client.player.distanceTo(entity) <= 32.0f) nearby.add(entity);
                        }
                        nearby.sort(Comparator.comparingDouble(client.player::distanceTo));

                        graphics.drawString(client.font, "ENTITY RADAR:", 8, y, 0xFFB78CFF, true);
                        y += 11;

                        int shown = 0;
                        for (Entity entity : nearby) {
                            if (shown++ >= maxEntries) break;
                            double distance = client.player.distanceTo(entity);
                            String line = entity.getName().getString() + "  " + (int) distance + "m";
                            graphics.drawString(client.font, line, 8, y, 0xFFE8E0F2, true);
                            y += 10;
                        }
                    }
                }
        );
    }

    private static void saveWaypoint() {
        Properties properties = new Properties();
        properties.setProperty("label", waypointLabel);
        properties.setProperty("x", Double.toString(waypointX));
        properties.setProperty("y", Double.toString(waypointY));
        properties.setProperty("z", Double.toString(waypointZ));
        try {
            Files.createDirectories(WAYPOINT_FILE.getParent());
            try (var output = Files.newOutputStream(WAYPOINT_FILE)) {
                properties.store(output, "OHH PRO waypoint");
            }
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    private static void loadWaypoint() {
        if (!Files.exists(WAYPOINT_FILE)) return;
        Properties properties = new Properties();
        try (var input = Files.newInputStream(WAYPOINT_FILE)) {
            properties.load(input);
            waypointLabel = properties.getProperty("label", "Waypoint");
            waypointX = Double.parseDouble(properties.getProperty("x", "0"));
            waypointY = Double.parseDouble(properties.getProperty("y", "0"));
            waypointZ = Double.parseDouble(properties.getProperty("z", "0"));
            waypointSet = true;
        } catch (IOException | NumberFormatException exception) {
            exception.printStackTrace();
        }
    }
}
